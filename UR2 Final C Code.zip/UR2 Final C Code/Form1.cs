﻿using Emgu.CV;
using Emgu.CV.CvEnum;
using Emgu.CV.Structure;
using Emgu.CV.Util;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UR2_Final_C_Code
{
    public partial class Form1 : Form
    {

        VideoCapture _capture;
        Thread _captureThread;
        SerialPort arduinoSerial = new SerialPort();
        bool enableCoordinateSending = false;
        Thread serialMonitoringThread;
        //Stopwatch stopwatch = new Stopwatch();


        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // create the capture object and processing thread
            _capture = new VideoCapture(1);
            _captureThread = new Thread(ProcessImage);
            _captureThread.Start();
            


            try
            {
                arduinoSerial.PortName = "COM17";
                arduinoSerial.BaudRate = 9600;
                arduinoSerial.Open();
                serialMonitoringThread = new Thread(MonitorSerialData);
                serialMonitoringThread.Start();
                XData.Text = "5";
                YData.Text = "5";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error Initializing COM port");
                Close();
            }
            

        }

        private void ProcessImage()
        {
            //stopwatch.Start();
            //TimeSpan ts = stopwatch.Elapsed;
            while (_capture.IsOpened)
            {
                List<Shape> CentersList = new List<Shape>();
                //int TimerCount = 1;
                //ts = stopwatch.Elapsed;

                // frame maintenance
                Mat sourceFrame = _capture.QueryFrame();
                // resize to PictureBox aspect ratio
                int newHeight = (sourceFrame.Size.Height * Box1.Size.Width) / sourceFrame.Size.Width;
                Size newSize = new Size(Box1.Size.Width, newHeight);
                CvInvoke.Resize(sourceFrame, sourceFrame, newSize);
                // display the image in the source PictureBox
                Invoke(new Action(() =>
                {
                    Box1.Image = sourceFrame.ToBitmap();
                }));
                // copy the source image so we can display a copy with artwork without editing the original:
                Mat sourceFrameWithArt = sourceFrame.Clone();
                // create an image version of the source frame, will be used when warping the image
                Image<Bgr, byte> sourceFrameWarped = sourceFrame.ToImage<Bgr, byte>();
                // Isolating the ROI: convert to a gray, apply binary threshold:
                Image<Gray, byte> grayImg = sourceFrame.ToImage<Gray, byte>().ThresholdBinary(new Gray(125), new
                Gray(255));

                // Sample for gaussian blur:
                var blurredImage = new Mat();
                var cannyImage = new Mat();
                var decoratedImage = new Mat();
                CvInvoke.GaussianBlur(sourceFrame, blurredImage, new Size(9, 9), 0);
                // convert to B/W
                CvInvoke.CvtColor(blurredImage, blurredImage, typeof(Bgr), typeof(Gray));
                // apply canny:
                // NOTE: Canny function can frequently create duplicate lines on the same shape
                // depending on blur amount and threshold values, some tweaking might be needed.
                // You might also find that not using Canny and instead using FindContours on
                // a binary-threshold image is more accurate.
                CvInvoke.Canny(blurredImage, cannyImage, 150, 255);
                // make a copy of the canny image, convert it to color for decorating:
                CvInvoke.CvtColor(cannyImage, decoratedImage, typeof(Gray), typeof(Bgr));

                using (VectorOfVectorOfPoint contours = new VectorOfVectorOfPoint())
                {
                    // Build list of contours
                    CvInvoke.FindContours(grayImg, contours, null, RetrType.List, ChainApproxMethod.ChainApproxSimple);
                    // Selecting largest contour
                    if (contours.Size > 0)
                    {
                        double maxArea = 0;
                        List<double> areaList = new List<double>();
                        int chosen = 0;
                        //if (contours.Size > 0 && contours.Size < maxArea * 0.5)
                        for (int i = 0; i < contours.Size; i++)
                        {
                            VectorOfPoint contour = contours[i];
                            double area = CvInvoke.ContourArea(contour);
                            areaList.Add(area);
                            if (area > maxArea)
                            {
                                maxArea = area;
                                chosen = i;
                            }
                        }

                        Invoke(new Action(() =>
                        {
                            NumberOfContours.Text = $"There are {contours.Size - 1} contours detected";
                        }));

                        Rectangle boundingBoxtemp = CvInvoke.BoundingRectangle(contours[chosen]);
                        double X_cord = boundingBoxtemp.X;
                        double Y_cord = boundingBoxtemp.Y;
                        double Length = boundingBoxtemp.Width;
                        double Height = boundingBoxtemp.Height;

                        for (int i = 0; i < areaList.Count; i++)
                        {
                            if (i != chosen)
                            {
                                Rectangle boundingBox = CvInvoke.BoundingRectangle(contours[i]);
                                MarkDetectedObject(sourceFrameWithArt, contours[i], boundingBox, areaList[i], maxArea);
                                //contours.Draw(new CircleF(points[i], 5), new Bgr(Color.Red), 5);
                                //frame.Draw(new CircleF(points[i], 5), new Bgr(Color.Red), 5);

                                int ShapeType = -1;
                                double shape = (areaList[i] / maxArea) * 100;
                                if (shape > 3.5 && shape < 7)//square
                                {
                                    ShapeType = 0;
                                }
                                else if (shape > 0 && shape < 3.5)//triangle 
                                {
                                    ShapeType = 1;
                                }

                                //finds the x and y in pixels 
                                double X = boundingBox.X + boundingBox.Width / 2;
                                double Y = boundingBox.Y + boundingBox.Height / 2;

                                //converts to top left of paper
                                X = X - X_cord;
                                Y = Y - Y_cord;

                                //Converts to inches
                                X = (X / Length) * 11;
                                Y = (Y / Height) * 8.5;

                                X = X * 4;
                                Y = Y * 4;

                                Point center = new Point((int)X, (int)Y);                                

                                CentersList.Add(new Shape
                                {
                                    Center = new Point(center.X, center.Y),
                                    Type = ShapeType
                                });
                            }

                        }

                        // Display the version of the source image with the added artwork, simulating ROI focus:
                        Box2.Image = sourceFrameWithArt.ToBitmap();
                        // Warp the image, output it
                        Box3.Image = WarpImage(sourceFrameWarped, contours[chosen]).ToBitmap();

                        //writes point to list on screen in inches
                        //WritePoints(CentersList);

                        if (enableCoordinateSending) //&& CentersList.Count > 0
                        {
                            if (contours.Size == 1)
                            {
                                MessageBox.Show("No More Shapes");
                                Close();
                            }
                            int _xCenter = CentersList[0].Center.X;
                            int _yCenter = CentersList[0].Center.Y;
                            int _shapeType = CentersList[0].Type;
                            byte[] buffer = new byte[5] {
                            Encoding.ASCII.GetBytes("<")[0],
                            Convert.ToByte(_xCenter),
                            Convert.ToByte(_yCenter),
                            Convert.ToByte(_shapeType),
                            Encoding.ASCII.GetBytes(">")[0]
                            };
                            arduinoSerial.Write(buffer, 0, 5);

                            enableCoordinateSending = false;
                        }

                        
                        /*if (ts.TotalSeconds > 60000 * TimerCount)
                        {
                            TimerCount++;
                            //stopwatch.Stop();
                            if (contours.Size == 0)
                            {
                                MessageBox.Show("No More Shapes");
                                Close();
                            }
                            int _xCenter = CentersList[0].Center.X;
                            int _yCenter = CentersList[0].Center.Y;
                            int _shapeType = CentersList[0].Type;
                            byte[] buffer = new byte[5] {
                            Encoding.ASCII.GetBytes("<")[0],
                            Convert.ToByte(_xCenter),
                            Convert.ToByte(_yCenter),
                            Convert.ToByte(_shapeType),
                            Encoding.ASCII.GetBytes(">")[0]
                            };
                            arduinoSerial.Write(buffer, 0, 5);

                            enableCoordinateSending = false;
                            //stopwatch.Start();
                            
                        }*/
                    }

                    // output images:
                    Box1.Image = sourceFrame.ToBitmap();
                    //Box3.Image = decoratedImage.ToBitmap();

                }


            }
        }



        private void WritePoints(List<Shape> CentersList)
        {
            Invoke(new Action(() =>
            {
                if (CentersList.Count >= 1)
                {
                    point1.Text = $"Shape 1: {CentersList[0].Center.X}, {CentersList[0].Center.Y}, {CentersList[0].Type}";
                }
                else
                {
                    point1.Text = $"0, 0, 0";
                }

                if (CentersList.Count >= 2)
                {
                    point2.Text = $"Shape 2: {CentersList[1].Center.X}, {CentersList[1].Center.Y}, {CentersList[1].Type}";
                }
                else
                {
                    point2.Text = $"0, 0, 0";
                }

                if (CentersList.Count >= 3)
                {
                    point3.Text = $"Shape 3: {CentersList[2].Center.X}, {CentersList[2].Center.Y}, {CentersList[2].Type}";
                }
                else
                {
                    point3.Text = $"0, 0, 0";
                }

                if (CentersList.Count >= 4)
                {
                    point4.Text = $"Shape 4: {CentersList[3].Center.X}, {CentersList[3].Center.Y}, {CentersList[3].Type}";
                }
                else
                {
                    point4.Text = $"0, 0, 0";
                }

                if (CentersList.Count >= 5)
                {
                    point5.Text = $"Shape 5: {CentersList[4].Center.X}, {CentersList[4].Center.Y}, {CentersList[4].Type}";
                }
                else
                {
                    point5.Text = $"0, 0, 0";
                }

            }));
        }

        private void SendDataButton_Click(object sender, EventArgs e)
        {

            if (!enableCoordinateSending)
            {
                MessageBox.Show("Temporarily locked...");
                return;
            }
            int x = -1;
            int y = -1;
            if (int.TryParse(XData.Text, out x) && int.TryParse(YData.Text, out y))
            {
                byte[] buffer = new byte[5] {
                Encoding.ASCII.GetBytes("<")[0],
                Convert.ToByte(x),
                Convert.ToByte( y),
                Convert.ToByte(0),
                Encoding.ASCII.GetBytes(">")[0]
                };
                arduinoSerial.Write(buffer, 0, 5);
            }
            else
            {
                MessageBox.Show("X and Y values must be integers", "Unable to parse coordinates");
            }
            
        }

        private void MonitorSerialData()
        {
            while (true)
            {
                // block until \n character is received, extract command data
                string msg = arduinoSerial.ReadLine();
                // confirm the string has both < and > characters
                if (msg.IndexOf("<") == -1 || msg.IndexOf(">") == -1)
                {
                    continue;
                }
                // remove everything before (and including) the < character
                msg = msg.Substring(msg.IndexOf("<") + 1);
                // remove everything after (and including) the > character
                msg = msg.Remove(msg.IndexOf(">"));
                // if the resulting string is empty, disregard and move on
                if (msg.Length == 0)
                {
                    continue;
                }
                // parse the command
                if (msg.Substring(0, 1) == "S")
                {
                    // command is to suspend, toggle states accordingly:
                    ToggleFieldAvailability(msg.Substring(1, 1) == "1");
                    //enableCoordinateSending = true;

                }
                else if (msg.Substring(0, 1) == "P")
                {
                    // command is to display the point data, output to the text field:
                    Invoke(new Action(() =>
                    {
                        ReturnText.Text = $"Returned Point Data: {msg.Substring(1)}";
                    }));
                    //enableCoordinateSending = true;
                }
                //enableCoordinateSending = true;
            }
        }


        private void ToggleFieldAvailability(bool suspend)
        {
            Invoke(new Action(() =>
            {
                enableCoordinateSending = !suspend;
                lockStateToolStripStatusLabel.Text = $"State: {(suspend ? "Locked" : "Unlocked")}";
            }));
        }
        
        private static Image<Bgr, Byte> WarpImage(Image<Bgr, byte> frame, VectorOfPoint contour)
        {
            // set the output size:
            var size = new Size(frame.Width, frame.Height);
            using (VectorOfPoint approxContour = new VectorOfPoint())
            {
                CvInvoke.ApproxPolyDP(contour, approxContour, CvInvoke.ArcLength(contour, true) * 0.05, true);
                // get an array of points in the contour
                Point[] points = approxContour.ToArray();
                // if array length isn't 4, something went wrong, abort warping process (for demo, draw points instead)
                if (points.Length != 4)
                {
                    for (int i = 0; i < points.Length; i++)
                    {
                        frame.Draw(new CircleF(points[i], 5), new Bgr(Color.Red), 5);
                    }
                    return frame;
                }
                IEnumerable<Point> query = points.OrderBy(point => point.Y).ThenBy(point => point.X);
                PointF[] ptsSrc = new PointF[4];
                PointF[] ptsDst = new PointF[] { new PointF(0, 0), new PointF(size.Width - 1, 0), new PointF(0, size.Height - 1),
                new PointF(size.Width - 1, size.Height - 1) };
                for (int i = 0; i < 4; i++)
                {
                    ptsSrc[i] = new PointF(query.ElementAt(i).X, query.ElementAt(i).Y);
                }
                using (var matrix = CvInvoke.GetPerspectiveTransform(ptsSrc, ptsDst))
                {
                    using (var cutImagePortion = new Mat())
                    {
                        CvInvoke.WarpPerspective(frame, cutImagePortion, matrix, size, Inter.Cubic);
                        return cutImagePortion.ToImage<Bgr, Byte>();
                    }
                }
            }
        }

        private static void MarkDetectedObject(Mat frame, VectorOfPoint contour, Rectangle boundingBox, double area, double M_area)
        {
            // Drawing contour and box around it
            int ShapeType = -1;
            double shape = (area / M_area) * 100;
            if (shape > 3.5 && shape < 7)//square
            {
                CvInvoke.Polylines(frame, contour, true, new Bgr(Color.Blue).MCvScalar);
                ShapeType = 0;
            }
            else if (shape > 0 && shape < 3.5)//triangle 
            {
                CvInvoke.Polylines(frame, contour, true, new Bgr(Color.Green).MCvScalar);
                ShapeType = 1;
            }

            CvInvoke.Rectangle(frame, boundingBox, new Bgr(Color.Red).MCvScalar);
            // Write information next to marked object
            Point center = new Point(boundingBox.X + boundingBox.Width / 2, boundingBox.Y + boundingBox.Height / 2);
            var info = new string[] {
            $"Area: {area}",
            $"Position: {center.X}, {center.Y}"
            };
            WriteMultilineText(frame, info, new Point(center.X, boundingBox.Bottom + 12));

            int thickness = 1;
            CvInvoke.Circle(frame, center, 0, new Bgr(Color.Red).MCvScalar, thickness);
            /*var info2 = new string[] {
            $"."
            };
            WriteMultilineText(frame, info2, new Point(center.X - 1, center.Y + 1));*/

        }

        private static void WriteMultilineText(Mat frame, string[] lines, Point origin)
        {
            for (int i = 0; i < lines.Length; i++)
            {
                int y = i * 10 + origin.Y; // Moving down on each line
                CvInvoke.PutText(frame, lines[i], new Point(origin.X, y),
                FontFace.HersheyPlain, 0.8, new Bgr(Color.Red).MCvScalar);
            }
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            // terminate the image processing thread to avoid orphaned processes
            _captureThread.Abort();
        }

        private void Enable_Click(object sender, EventArgs e)
        {
            enableCoordinateSending = true;
        }
    }

    public class Shape
    {
        public Point Center { get; set; }
        public int Type { get; set; }

    }
}
