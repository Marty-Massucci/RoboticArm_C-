﻿namespace UR2_Final_C_Code
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.NumberOfContours = new System.Windows.Forms.Label();
            this.Box3 = new System.Windows.Forms.PictureBox();
            this.Box2 = new System.Windows.Forms.PictureBox();
            this.Box1 = new System.Windows.Forms.PictureBox();
            this.SendDataButton = new System.Windows.Forms.Button();
            this.YData = new System.Windows.Forms.TextBox();
            this.XData = new System.Windows.Forms.TextBox();
            this.lockStateToolStripStatusLabel = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.Enable = new System.Windows.Forms.Button();
            this.point5 = new System.Windows.Forms.Label();
            this.point4 = new System.Windows.Forms.Label();
            this.point3 = new System.Windows.Forms.Label();
            this.point2 = new System.Windows.Forms.Label();
            this.point1 = new System.Windows.Forms.Label();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.ReturnText = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.Box3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Box2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Box1)).BeginInit();
            this.SuspendLayout();
            // 
            // NumberOfContours
            // 
            this.NumberOfContours.AutoSize = true;
            this.NumberOfContours.Location = new System.Drawing.Point(636, 244);
            this.NumberOfContours.Name = "NumberOfContours";
            this.NumberOfContours.Size = new System.Drawing.Size(29, 13);
            this.NumberOfContours.TabIndex = 8;
            this.NumberOfContours.Text = "label";
            // 
            // Box3
            // 
            this.Box3.Location = new System.Drawing.Point(639, 47);
            this.Box3.Name = "Box3";
            this.Box3.Size = new System.Drawing.Size(248, 179);
            this.Box3.TabIndex = 7;
            this.Box3.TabStop = false;
            // 
            // Box2
            // 
            this.Box2.Location = new System.Drawing.Point(344, 47);
            this.Box2.Name = "Box2";
            this.Box2.Size = new System.Drawing.Size(248, 179);
            this.Box2.TabIndex = 6;
            this.Box2.TabStop = false;
            // 
            // Box1
            // 
            this.Box1.Location = new System.Drawing.Point(52, 47);
            this.Box1.Name = "Box1";
            this.Box1.Size = new System.Drawing.Size(248, 179);
            this.Box1.TabIndex = 5;
            this.Box1.TabStop = false;
            // 
            // SendDataButton
            // 
            this.SendDataButton.Location = new System.Drawing.Point(963, 183);
            this.SendDataButton.Name = "SendDataButton";
            this.SendDataButton.Size = new System.Drawing.Size(107, 23);
            this.SendDataButton.TabIndex = 15;
            this.SendDataButton.Text = "Send Coordinates";
            this.SendDataButton.UseVisualStyleBackColor = true;
            this.SendDataButton.Click += new System.EventHandler(this.SendDataButton_Click);
            // 
            // YData
            // 
            this.YData.Location = new System.Drawing.Point(983, 123);
            this.YData.Name = "YData";
            this.YData.Size = new System.Drawing.Size(100, 20);
            this.YData.TabIndex = 14;
            // 
            // XData
            // 
            this.XData.Location = new System.Drawing.Point(983, 70);
            this.XData.Name = "XData";
            this.XData.Size = new System.Drawing.Size(100, 20);
            this.XData.TabIndex = 13;
            // 
            // lockStateToolStripStatusLabel
            // 
            this.lockStateToolStripStatusLabel.AutoSize = true;
            this.lockStateToolStripStatusLabel.Location = new System.Drawing.Point(66, 244);
            this.lockStateToolStripStatusLabel.Name = "lockStateToolStripStatusLabel";
            this.lockStateToolStripStatusLabel.Size = new System.Drawing.Size(35, 13);
            this.lockStateToolStripStatusLabel.TabIndex = 12;
            this.lockStateToolStripStatusLabel.Text = "State:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(960, 126);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(17, 13);
            this.label2.TabIndex = 10;
            this.label2.Text = "Y:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(960, 73);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(17, 13);
            this.label1.TabIndex = 9;
            this.label1.Text = "X:";
            // 
            // Enable
            // 
            this.Enable.Location = new System.Drawing.Point(963, 239);
            this.Enable.Name = "Enable";
            this.Enable.Size = new System.Drawing.Size(75, 23);
            this.Enable.TabIndex = 16;
            this.Enable.Text = "Enable";
            this.Enable.UseVisualStyleBackColor = true;
            this.Enable.Click += new System.EventHandler(this.Enable_Click);
            // 
            // point5
            // 
            this.point5.AutoSize = true;
            this.point5.Location = new System.Drawing.Point(66, 417);
            this.point5.Name = "point5";
            this.point5.Size = new System.Drawing.Size(29, 13);
            this.point5.TabIndex = 17;
            this.point5.Text = "label";
            // 
            // point4
            // 
            this.point4.AutoSize = true;
            this.point4.Location = new System.Drawing.Point(66, 382);
            this.point4.Name = "point4";
            this.point4.Size = new System.Drawing.Size(29, 13);
            this.point4.TabIndex = 18;
            this.point4.Text = "label";
            // 
            // point3
            // 
            this.point3.AutoSize = true;
            this.point3.Location = new System.Drawing.Point(66, 351);
            this.point3.Name = "point3";
            this.point3.Size = new System.Drawing.Size(29, 13);
            this.point3.TabIndex = 19;
            this.point3.Text = "label";
            // 
            // point2
            // 
            this.point2.AutoSize = true;
            this.point2.Location = new System.Drawing.Point(66, 322);
            this.point2.Name = "point2";
            this.point2.Size = new System.Drawing.Size(29, 13);
            this.point2.TabIndex = 20;
            this.point2.Text = "label";
            // 
            // point1
            // 
            this.point1.AutoSize = true;
            this.point1.Location = new System.Drawing.Point(66, 297);
            this.point1.Name = "point1";
            this.point1.Size = new System.Drawing.Size(29, 13);
            this.point1.TabIndex = 21;
            this.point1.Text = "label";
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // ReturnText
            // 
            this.ReturnText.AutoSize = true;
            this.ReturnText.Location = new System.Drawing.Point(1200, 167);
            this.ReturnText.Name = "ReturnText";
            this.ReturnText.Size = new System.Drawing.Size(35, 13);
            this.ReturnText.TabIndex = 24;
            this.ReturnText.Text = "label3";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1455, 511);
            this.Controls.Add(this.ReturnText);
            this.Controls.Add(this.point1);
            this.Controls.Add(this.point2);
            this.Controls.Add(this.point3);
            this.Controls.Add(this.point4);
            this.Controls.Add(this.point5);
            this.Controls.Add(this.Enable);
            this.Controls.Add(this.SendDataButton);
            this.Controls.Add(this.YData);
            this.Controls.Add(this.XData);
            this.Controls.Add(this.lockStateToolStripStatusLabel);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.NumberOfContours);
            this.Controls.Add(this.Box3);
            this.Controls.Add(this.Box2);
            this.Controls.Add(this.Box1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.Box3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Box2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Box1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label NumberOfContours;
        private System.Windows.Forms.PictureBox Box3;
        private System.Windows.Forms.PictureBox Box2;
        private System.Windows.Forms.PictureBox Box1;
        private System.Windows.Forms.Button SendDataButton;
        private System.Windows.Forms.TextBox YData;
        private System.Windows.Forms.TextBox XData;
        private System.Windows.Forms.Label lockStateToolStripStatusLabel;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button Enable;
        private System.Windows.Forms.Label point5;
        private System.Windows.Forms.Label point4;
        private System.Windows.Forms.Label point3;
        private System.Windows.Forms.Label point2;
        private System.Windows.Forms.Label point1;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.Label ReturnText;
        private System.Windows.Forms.Timer timer1;
    }
}

